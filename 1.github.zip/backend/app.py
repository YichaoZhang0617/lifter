#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# project :
# Author :Xiaochao

from flask import Flask, jsonify
from exts import db
import config
from models import User, Plant
from flask_cors import CORS
from flask import request
import json
from datetime import datetime

app = Flask(__name__)
app.config.from_object(config)
# 给数据库赋值
db.init_app(app)

# 跨域访问，指定域名cors = CORS(app, resources={r"/api/*": {"origins": "*"}})
CORS(app, supports_credentials=True)


# 使用 flask-scripts 来使用 flask-Migrate ，因此先要创建manage.py文件C:\Users\Chao\Desktop\Flask\lifter
@app.route('/')
def index():
    # 新增用户，注意这里的数据提交必须还是通过下面的session,数据库迁移、更新那一套没用！！！
    user1 = User(email='sfaefaso@siemens.com', username='sfaefaso', password='123456', role='Admin',
                 updateTime=str(datetime.now()))
    db.session.add(user1)
    db.session.commit()

    # 由于不能直接得到新增用户的id，所以需要存入数据库后再从数据库中取新增用户对应的id
    backuser1 = User.query.filter(User.username == 'sfaefaso' ).first()
    plant1 = Plant(plantId='I', totalNumber='36', highAlarm='0', mediumAlarm='0', normalRunning='125', status='10',
                   planMaintenance='15', mediumMaintenance='10', highMaintenance='5',
                   basicInfo='Shanghai Jiading Malu', user_id=backuser1.id)
    plant2 = Plant(plantId='II', totalNumber='30', highAlarm='0', mediumAlarm='0', normalRunning='100', status='8',
                   planMaintenance='15', mediumMaintenance='10', highMaintenance='5',
                   basicInfo='Shanghai Jiading Malu', user_id=backuser1.id)
    plant3 = Plant(plantId='III', totalNumber='35', highAlarm='4', mediumAlarm='5', normalRunning='200', status='80',
                   planMaintenance='18', mediumMaintenance='13', highMaintenance='8',
                   basicInfo='Shanghai Jiading Malu', user_id=backuser1.id)
    plant4 = Plant(plantId='IV', totalNumber='36', highAlarm='0', mediumAlarm='4', normalRunning='180', status='60',
                   planMaintenance='16', mediumMaintenance='11', highMaintenance='7',
                   basicInfo='Shanghai Jiading Malu', user_id=backuser1.id)
    db.session.add(plant1)
    db.session.add(plant2)
    db.session.add(plant3)
    db.session.add(plant4)
    db.session.commit()

    user2 = User(email='xiaochao@siemens.com', username='xiaochao', password='111111', role='Admin',
                 updateTime=str(datetime.now()))
    db.session.add(user2)
    db.session.commit()
    # 由于不能直接得到新增用户的id，所以需要存入数据库后再从数据库中取新增用户对应的id
    return '<h1>Hello World!</h1>'

''' 注册用户 '''
@app.route('/registerUser', methods=['POST'])
def registerUser():
    data = request.get_data()
    json_data = json.loads(data.decode('utf-8'))
    registerUser = json_data.get('username')
    print(registerUser)
    # 判断该用户是否存在，如果存在返回空，不存在存储到数据库中
    if (User.query.filter(User.username == registerUser).first()) == None:
        user = User(email=json_data.get('email'), username=json_data.get('username'),
                    password=json_data.get('password'), role=json_data.get('role'),
                    updateTime=str(datetime.now()))
        db.session.add(user)
        db.session.commit()
        ''' 下面新增Plant的代码较麻烦，需寻找简单方法'''
        response = dict(username=json_data.get('username'), password=json_data.get('password'))
        return jsonify(response)
    else:
        response = dict(username='', password='')
        return jsonify(response)


'''确定登录页面时确定用户的合法身份'''
@app.route('/queryUserName/<loginname>', methods=['GET'])
def queryUserName(loginname):
    print(User.query.filter(User.username == loginname).first())
    # 判断该用户是否存在，如果存在查找用户信息，不存在返回全空
    if (User.query.filter(User.username == loginname).first()) != None:
        user = User.query.filter(User.username == loginname).first()
        response = dict(username=user.username, password=user.password)
    else:
        response = dict(username='', password='')
    return jsonify(response)


'''查询当前登录用户的信息'''
@app.route('/queryUser/<name>', methods=['GET'])
def queryUser(name):
    # 在数据库中查询当前用户的 信息，并回传在前端显示
    user = User.query.filter(User.username == name).first()
    response = dict(username=user.username, email=user.email, password=user.password, role=user.role)
    return jsonify(response)


''' 更改当前登录用户信息 , 注意这里的更改既包括登录用户的更改，还包括管理员的更改，所有这里面的内容修改时一定要注意！！！ '''
@app.route('/updateUser', methods=['POST'])
def updateUser():
    # 得到修改的用户信息，并上传到数据库
    data = request.get_data()
    json_data = json.loads(data.decode('utf-8'))
    print(json_data)
    # 当前用户修改信息之前的用户名，查询到数据库中对应的数据进行更改
    rawusername = json_data.get('rawusername')
    user = User.query.filter(User.username == rawusername).first()
    # 修改数据库中用户信息
    user.username = json_data.get('username')
    user.email = json_data.get('email')
    user.password = json_data.get('password')
    user.role = json_data.get('role')
    db.session.commit()
    # return username
    response = dict(username=user.username, email=user.email, password=user.password, role=user.role)
    return jsonify(response)


''' users 显示所有用户 '''
@app.route('/queryAllUsers', methods=['GET'])
def queryAllUsers():
    # 显示所有的用户信息
    users = User.query.order_by(User.id).all()
    # 写一个二维字典，将所有的用户信息打印出来,外维为用户的id信息
    d = []
    for user in users:
        response = dict(username=user.username, email=user.email, role=user.role, updateTime=user.updateTime)
        d.append(response)
    print(d)
    return jsonify(d)


''' Name 关键字搜索框 '''
@app.route('/queryUserNameSearch/<name>', methods=['GET'])
def queryUserNames(name):
    # 因为用户名是唯一的，所有搜索过后会最多显示一个用户
    print(name)
    user = User.query.filter(User.username == name).first()
    d = []  # 必须有这个步骤，就是将dict类型的数据提交到d数组中，然后回传到前端才不会报错！！！
    if (user != None):
        # 关键字的有效时，输出为一个用户
        response = dict(username=user.username, email=user.email, password=user.password, role=user.role,
                        updateTime=user.updateTime)
        d.append(response)
    else:
        # 关键字的无效时，无用户输出，此时返回一个空的d数组，可以保证前端显示无数据！
        pass
    return jsonify(d)


''' Email 关键字搜索框 '''
@app.route('/queryUserEmailSearch/<email>', methods=['GET'])
def queryUserEmailSearch(email):
    # 因为Email不是唯一的，所有搜索过后会可能会显示一个用户、无数个用户以及没有用户
    print(email)
    users = User.query.filter(User.email == email).all()
    d = []
    if (users == None):
        # 关键字的无效时，无用户输出，此时返回一个空的d数组，可以保证前端显示无数据！
        pass
    else:
        # 写一个二维字典，将所有的用户信息打印出来,外维为用户的id信息
        for user in users:
            response = dict(username=user.username, email=user.email, role=user.role, updateTime=user.updateTime)
            d.append(response)
    return jsonify(d)


''' 添加用户 '''
@app.route('/addUser', methods=['POST'])
def addUser():
    data = request.get_data()
    json_data = json.loads(data.decode('utf-8'))
    username = json_data.get('username')
    email = json_data.get('email')
    password = json_data.get('password')
    role = json_data.get('role')

    print(username, email, password, role)
    # 得到你修改的是哪一个用户信息，然后进行更新

    user = User(email=str(email), username=str(username), password=str(password), role=str(role),
                updateTime=datetime.now())
    db.session.add(user)
    db.session.commit()

    return '<h1>Hello World!</h1>'


''' users 页面删除用户 '''
@app.route('/deleteUser', methods=['POST'])
def deleteUser():
    data = request.get_data()
    json_data = json.loads(data.decode('utf-8'))
    print(json_data.get('username'))
    user = User.query.filter(User.username == json_data.get('username')).first()
    db.session.delete(user)
    db.session.commit()

    return '<h1>Hello World!</h1>'

''' 显示某用户下的所有Plant，注意如果回传 name ，那么其接口还应该改变 '''
@app.route('/queryAllPlant', methods=['GET'])
def queryAllPlant():
    plants = Plant.query.filter().all()
    # 利用user.id 找出其对应的plant
    print(plants)
    # 写一个二维字典，将所有的用户信息打印出来,外维为用户的id信息
    d = []
    for plant in plants:
        response = dict(plantId=plant.plantId,totalNumber=plant.totalNumber,highAlarm=plant.highAlarm,mediumAlarm=plant.mediumAlarm,
                        normalRunning = plant.normalRunning,status = plant.status,planMaintenance =plant.planMaintenance,mediumMaintenance=plant.mediumMaintenance,
                        highMaintenance = plant.highMaintenance,basicInfo= plant.basicInfo)
        d.append(response)
    print(d)
    return jsonify(d)
if __name__ == '__main__':
    app.run(debug=True)
