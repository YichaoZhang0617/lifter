#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from flask_sqlalchemy import SQLAlchemy
# 初始化但没有赋值
db = SQLAlchemy()