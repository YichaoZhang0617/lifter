#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# project :
# Author :Xiaochao

from exts import db


class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(50), nullable=False)
    username = db.Column(db.String(50), nullable=False)
    password = db.Column(db.String(50), nullable=False)
    role = db.Column(db.String(100), nullable=False)
    updateTime = db.Column(db.DateTime, nullable=False)

    # 设置外键关联role
    # plant_id = db.Column(db.Integer, db.ForeignKey('plant.id'))
    # 当需要新增一项时,只需要在终端进行数据库迁移和更新操作就可以了！！！
    # tags = db.Column(db.Text, nullable=False)


class Plant(db.Model):
    __tablename__ = 'plant'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    plantId = db.Column(db.String(50), nullable=False)
    totalNumber = db.Column(db.Integer, nullable=False)
    highAlarm = db.Column(db.Integer, nullable=False)
    mediumAlarm = db.Column(db.Integer, nullable=False)
    normalRunning = db.Column(db.Integer, nullable=False)
    status = db.Column(db.Integer, nullable=False)  # 灯是哪个颜色亮
    planMaintenance = db.Column(db.Integer, nullable=False)
    mediumMaintenance = db.Column(db.Integer, nullable=False)
    highMaintenance = db.Column(db.Integer, nullable=False)
    basicInfo = db.Column(db.String(100), nullable=False)

    # 注意这里的 user_id和User表中的id对应值相同
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    author = db.relationship('User', backref=db.backref('plants'))
    # 正向访问为 Plant 访问 User，反向访问为 User 访问 Plant
    # 如果你想知道这个plant的作者，可以通过plant.author访问；如果想知道这个user的所有plant，可以通过author.plants实现

# 建立触发器
# sql = '''
# create or replace trigger auth_secure after insert or update or DELETE
# on user for each row
# begin
# END;
# '''
# cursor = db.cursor()
# cursor.execute(sql)