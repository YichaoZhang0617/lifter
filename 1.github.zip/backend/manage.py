#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from flask_script import Manager
from app import app
from  flask_migrate import Migrate,MigrateCommand
from exts import db
from models import User,Plant

manage = Manager(app)

# 模型  ->  迁移文件  ->  表

# 1.要使用 flask_migrate ,必须绑定app和db
migrate =  Migrate(app,db)

# 2.把MigrateCommand命令添加到manage中
manage.add_command('db',MigrateCommand)

if __name__ == '__main__':
    manage.run()