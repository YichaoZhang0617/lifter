
# 连接mysql
# mysql+pymysql://user:password@ip:port/db_name
# DIALECT = 'mysql'
# DRIVER = 'pymysql'
# USERNAME = 'root'
# PASSWORD = '123456'
# HOST = 'localhost'
# PORT = '3306'
# DATABASE = 'mysql'
#
# SQLALCHEMY_DATABASE_URI = "{}+{}://{}:{}@{}:{}/{}?charset=utf8".format(DIALECT, DRIVER, USERNAME, PASSWORD, HOST
#                                                                        , PORT, DATABASE)
# SQLALCHEMY_TRACK_MODIFICATIONS = False

# 连接postgre
# postgresql+psycopg2://user:password@ip:port/db_name
DIALECT = 'postgresql'
DRIVER = 'psycopg2'
USERNAME = 'postgres'
PASSWORD = '123456'
HOST = 'localhost'
PORT = '5432'
DATABASE = 'postgres'

# 千万要注意这里的连接用client_encoding，不是charset！！！
SQLALCHEMY_DATABASE_URI = "{}+{}://{}:{}@{}:{}/{}?client_encoding=utf8".format(DIALECT, DRIVER, USERNAME, PASSWORD, HOST
                                                                       , PORT, DATABASE)
SQLALCHEMY_TRACK_MODIFICATIONS = False

# sqlite:///database.db