# Angualr 安装步骤     

*****************************    
**1、安装 `Node.js`**    

版本号为 `v10.15.3` ，安装参考链接为 `https://nodejs.org/en/`     

<div align=center>
	<img src="./assets/node.png" width="80%">
</div>    


**2、安装 `Angular`**     

版本号 `@angular/cli`: `^7.3.9`，`@angular/core`: `^7.2.15`，安装参考链接为 `https://jingyan.baidu.com/article/fd8044fa0f2a145031137a22.html`      

<div align=center>
	<img src="./assets/angular.png" width="80%">
</div>       

**3、注意事项**   

1）将项目 `.zip` 文档下载解压后，在解压文件的目录下输入 `npm install` ，安装模块资源库，注意不要用 `cnpm` ，可能会出现库文件导入错误；安装完成后控制台下输入`ng serve`启动程序，启动完成后在`chrome`浏览器端输入 `localhost:4200` 即可进入登录界面;    
2）单独安装组件库 `ng-norro` 时，一定要注意版本问题，参考版本用的是 `Angular7` ，不能直接在 `ng-zorro` 官网下载最新版，需要的 `ng-zorro` 版本为 `7.4.1` ，注意下载安装后手动将 `ng-zorro` 的 `css` 文件路径写到 `angular.json` 文件中！     

<div align=center>
	<img src="./assets/angularjson.png" width="80%">
</div>    

**ng-zorro的官网链接为 `https://ng.ant.design/docs/introduce/zh`**     
3）单独安装 `Angular` 依赖的 `Echarts` 依赖库, `npm install echarts --save` , `npm install ngx-echarts --save`，然后在 `app.commponent.module` 文件中导入依赖库。      

# Python 安装步骤      

***********************     

**1.安装 `python3.6.5` 版本,并配置环境变量 `path`**       

<div align=center>
	<img src="./assets/python.png" width="80%">
</div>     

**2.安装 `flask` 及相关的库**     
`pip install Flask`    
`pip install Flask-Cors`    
`pip install Flask-Migrate`     
`pip install Flask-SQLAlchemy`    
`pip install Script`    
`pip install psycopg2`    

**3、注意事项**   
1）配置环境， `python` 安装完成后，一定要配置 `python` 和 `pip` 的环境变量，安装过程中会提示是否配置环境变量，点击是即可；   
2）安装 `flask` 的资源库 `sqlalchemy` 时，当出现下图情况时，一定要检查安装的 `sqlalchemy` 里面包括下面的这些文件！！！   

<div align=center>
	<img src="./assets/flask_sqlalchemy.png" width="80%">
</div>     

出现这种问题后，改用控制台目录下安装 `sqlalchemy` ，或者直接从别人的库中拷过来。   

# Postgresql安装步骤    

*******************************   

**1.官网下载postgresql**    
参考版本为 `10.5.2` ，安装完成点击 `pgAdmin4` 连接数据库，如果连接失败，则需要在搜索框搜索 *`服务`*，然后进入服务页面，找到 `Postgresql`然后右键启动即可；   

<div align=center>
	<img src="./assets/service.png" width="80%">
</div>   

**2.更改config文件**   
数据库安装完成后，建立数据库与 `python` 之间的连接，更改 `config.py`文件中的 `username`、`password`、`database` 等。  

<div align=center>
	<img src="./assets/connect.png" width="80%">
</div> 
   

在控制台项目文件下依次键入 `python manage.py db init`,`python manage.py db migrate`,`python manage.py db upgrade`,然后在数据库中查看，会出现 `user` 和 `plant` 的空表，然后在控制台继续输入 `python app.py` 启动后台。   

<div align=center>
	<img src="./assets/migrate.png" width="80%">
</div>
 

在浏览器端输入 `127.0.0.1:5000` ，出现 `Hello,World!` 表示连接成功并导入了相关数据,此时表中新增两个 `user`和四个 `Plant` ，表示后台已成功启动！   

**3.注意事项**   
1）启动的步骤一定要注意，先完成数据库迁移创建表格后再启动后台服务器才能正常运转，顺序不能乱！    
2）当后台成功启动后，前端的登录页面才能正常登录！    
